package com.example.fooddelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    TextView headingView, usernameFieldView, passwordFieldView;
    Button loginButton, signupButton;
    Switch saveLoginDetails;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        headingView = findViewById(R.id.headingViewLogin);
        usernameFieldView = findViewById(R.id.usernameField);
        passwordFieldView = findViewById(R.id.passwordField);
        Bundle bundle = getIntent().getExtras();
        String entryActor = bundle.getString("entryRole", "");
        if(entryActor.equals("user")){
            headingView.setText("Welcome User");
        } else if (entryActor.equals("restaurent")) {
            headingView.setText("Restaurent");
        } else if (entryActor.equals("deliveryboy")) {
            headingView.setText("Delivery Staff");
        } else if (entryActor.equals("admin")) {
            headingView.setText("Administrator");
        }
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        if(saveLoginDetails.isChecked()){

        }

    }
}